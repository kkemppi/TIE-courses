def sort_integers_alphabetically(listing):

    list_sorted = sorted(listing, key=lambda listing: str(listing))
    return list_sorted