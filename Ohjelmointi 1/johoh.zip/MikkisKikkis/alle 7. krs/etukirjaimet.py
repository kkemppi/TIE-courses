def capitalize_initial_letters(sanat):
    syote = sanat.title()
    return syote