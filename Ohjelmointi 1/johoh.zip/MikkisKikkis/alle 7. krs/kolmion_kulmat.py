# Johdatus ohjelmointiin
# Parasetamol
# Mikko Kemppi, 272670, mikko.kemppi@tuni.fi

def calculate_angle(a=90, b=90):
    kulma = 180 - a - b
    return kulma

