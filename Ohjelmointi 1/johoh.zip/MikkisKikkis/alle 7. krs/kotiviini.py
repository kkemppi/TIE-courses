def main():
    luku = input("Enter the number of measurements: ")