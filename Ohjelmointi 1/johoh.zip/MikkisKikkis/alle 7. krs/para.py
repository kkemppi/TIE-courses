def teekkari(lkm, reaktio="hätkähdä", homma="ohjelmointi", toimet="ryhtyisi toimeen"):
    print( "Tämä teekkari ei ", reaktio, " vaikka antaisit sille ", lkm, " ",
           homma, "tehtävää, vaan ", toimet, ".", sep="" )