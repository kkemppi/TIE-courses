def main():
    row = input("Tell us your name: ")
    name = str(row)
    print("Hey ", name, end=",")
    print(" the printout formatting is going well!")
main()